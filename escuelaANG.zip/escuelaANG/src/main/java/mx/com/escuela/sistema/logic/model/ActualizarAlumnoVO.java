package mx.com.escuela.sistema.logic.model;

import java.io.Serializable;


public class ActualizarAlumnoVO implements Serializable{
	
	private static final long serialVersionUID = 2755141878041810085L;
	private int idUsuario;
	private double calificacion;
	private int idMateria;
	
	
	public int getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public double getCalificacion() {
		return calificacion;
	}
	public void setCalificacion(double calificacion) {
		this.calificacion = calificacion;
	}
	public int getIdMateria() {
		return idMateria;
	}
	public void setIdMateria(int idMateria) {
		this.idMateria = idMateria;
	}
	
	
	
	
		
	
}
