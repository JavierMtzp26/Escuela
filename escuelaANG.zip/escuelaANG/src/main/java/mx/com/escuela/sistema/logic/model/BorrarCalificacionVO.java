package mx.com.escuela.sistema.logic.model;

import java.io.Serializable;


public class BorrarCalificacionVO implements Serializable{
	
	private static final long serialVersionUID = 2755141878041810085L;
	private int idUsuario;
	private int idMateria;
	
	
	public int getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
	public int getIdMateria() {
		return idMateria;
	}
	public void setIdMateria(int idMateria) {
		this.idMateria = idMateria;
	}
	
	
	
		
	
}
