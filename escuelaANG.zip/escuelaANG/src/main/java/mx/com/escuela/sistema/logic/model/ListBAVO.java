package mx.com.escuela.sistema.logic.model;

import java.io.Serializable;
import java.util.List;

public class ListBAVO implements Serializable{
	
	private static final long serialVersionUID = 2755141878041810085L;
	private List<BusquedaAlumnoVO> listaBAVO;
	private double promedio;
	
	
	
	
	public List<BusquedaAlumnoVO> getListaBAVO() {
		return listaBAVO;
	}
	public void setListaBAVO(List<BusquedaAlumnoVO> listaBAVO) {
		this.listaBAVO = listaBAVO;
	}
	public double getPromedio() {
		return promedio;
	}
	public void setPromedio(double promedio) {
		this.promedio = promedio;
	}


	
	
	
}
