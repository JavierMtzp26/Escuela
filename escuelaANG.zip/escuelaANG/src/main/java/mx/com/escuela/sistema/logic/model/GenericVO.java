package mx.com.escuela.sistema.logic.model;

public class GenericVO {
	private String msg;
	private String succes;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getSucces() {
		return succes;
	}
	public void setSucces(String succes) {
		this.succes = succes;
	}


	
	
	
}
