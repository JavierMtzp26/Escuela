package mx.com.escuela.common.logic;

/**
 * Clase de constantes genericas
 * 
 * En los servicios se debe de aplicar toda la logica de negocio requerida
 * 
 * @author Miguel Angel Ortega Avila (mo351v)
 *
 */
public class Constants {

	public static final String USER_SYSTEM = "SYSTEM";
	
	public static class CDataSource {
		public static final int CORE_ESCUELA_SERVICE_ORACLE = 1;
	
	}

	
}