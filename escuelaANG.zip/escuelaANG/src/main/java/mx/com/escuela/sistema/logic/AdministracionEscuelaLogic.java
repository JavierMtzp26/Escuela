package mx.com.escuela.sistema.logic;




import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import mx.com.escuela.common.logic.Logic;
import mx.com.escuela.sistema.dao.OracleProcedures;
import mx.com.escuela.sistema.logic.model.ACPostVO;
import mx.com.escuela.sistema.logic.model.ActualizarAlumnoVO;
import mx.com.escuela.sistema.logic.model.BorrarCalificacionVO;
import mx.com.escuela.sistema.logic.model.GenericVO;
import mx.com.escuela.sistema.logic.model.ListBAVO;


public class AdministracionEscuelaLogic extends Logic{
	
	private final static Logger LOG = LogManager.getLogger(AdministracionEscuelaLogic.class);
	
	public AdministracionEscuelaLogic() {
		super(LOG);
	}

	public ListBAVO busquedaAlumno(int idUsuario){
		info("inicia busquedaAlumno  ::   AdministracionEscuelaLogic  :: ");
		ListBAVO busquedaAlum = new ListBAVO();
		OracleProcedures oracle = new OracleProcedures();
		try{
			busquedaAlum = oracle.busquedaAlumno(idUsuario);
		}catch(Exception e){
			info("[ERR] :: Se produjo un error busquedaAlumno  ::   AdministracionEscuelaLogic  ::   "+ e);
		}
		info("Finaliza busquedaAlumno  ::   AdministracionEscuelaLogic  :: ");
		return busquedaAlum;
	}


	public GenericVO agregarCalificacion(ACPostVO aCalif){
		info("inicia agregarCalificacion  ::   AdministracionEscuelaLogic  :: ");
		GenericVO response = new GenericVO();
		OracleProcedures oracle = new OracleProcedures();
		try{
			response = oracle.agregarCalificacion(aCalif);
		}catch(Exception e){
			info("[ERR] :: Se produjo un error agregarCalificacion  ::   AdministracionEscuelaLogic  ::   "+ e);
		}
		info("Finaliza agregarCalificacion  ::   AdministracionEscuelaLogic  :: ");
		return response;
	}
	
	
	public GenericVO actualizarAlumno(ActualizarAlumnoVO actAlum){
		info("inicia actualizarAlumno  ::   AdministracionEscuelaLogic  :: ");
		GenericVO response = new GenericVO();
		OracleProcedures oracle = new OracleProcedures();
		try{
			response = oracle.actualizarAlumno(actAlum);
		}catch(Exception e){
			info("[ERR] :: Se produjo un error actualizarAlumno  ::   AdministracionEscuelaLogic  ::   "+ e);
		}
		info("Finaliza actualizarAlumno  ::   AdministracionEscuelaLogic  :: ");
		return response;
	}
	
	public GenericVO borrarCalificacion(BorrarCalificacionVO borrarCali){
		info("inicia borrarCalificacion  ::   AdministracionEscuelaLogic  :: ");
		GenericVO response = new GenericVO();
		OracleProcedures oracle = new OracleProcedures();
		try{
			response = oracle.borrarCalificacion(borrarCali);
		}catch(Exception e){
			info("[ERR] :: Se produjo un error borrarCalificacion  ::   AdministracionEscuelaLogic  ::   "+ e);
		}
		info("Finaliza borrarCalificacion  ::   AdministracionEscuelaLogic  :: ");
		return response;
	}
	
	
	


}
