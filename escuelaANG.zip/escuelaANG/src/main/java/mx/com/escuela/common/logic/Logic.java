package mx.com.escuela.common.logic;

import org.apache.logging.log4j.Logger;

/**
 * Clase abstracta de servicio generica
 * 
 * En los servicios se debe de aplicar toda la logica de negocio requerida
 * 
 * @author Miguel Angel Ortega Avila (mo351v)
 *
 */
public abstract class Logic {
	
	protected Logger LOG;
	
	protected Logic(final Logger log) {
		LOG = log;
	}
	
	protected void info(String msg) {
		LOG.info(getNormaliceUser(Constants.USER_SYSTEM) + " -- " + msg);
	}
	
	protected void info(String user, String msg) {
		LOG.info(getNormaliceUser(user) + " -- " + msg);
	}
	
	protected void debug(final String msg) {
		LOG.debug(getNormaliceUser(Constants.USER_SYSTEM) + " -- " + msg);
	}

	protected void debug(String user, final Object ...data) {
		if (LOG.isDebugEnabled() && data != null) {
			for (Object o: data) {
				LOG.debug(getNormaliceUser(user) + " -- "  + ((o != null) ? o.toString() :  ""));
			}
		}
	}
	
	protected void error(String msg) {
		LOG.error(getNormaliceUser(Constants.USER_SYSTEM) + " -- " + msg);
	}
	
	protected void error(String msg, Throwable e) {
		LOG.error(getNormaliceUser(Constants.USER_SYSTEM) + " -- " + msg, e);
	}
	
	protected void error(String user, String msg) {
		LOG.error(getNormaliceUser(user) + " -- " + msg);
	}
	
	protected void error(String user, String msg, Throwable e) {
		LOG.error(getNormaliceUser(user) + " -- " + msg, e);
	}
	
	protected static String getNormaliceUser(String user) {
		String ret;
		int lg = 0;
		if (user == null) {
			ret = getNormaliceUser(Constants.USER_SYSTEM);
		} else {
			if (user.length() < 20) {
				lg = (20 - user.length());
				if (lg > 0) {
					ret = user + new String(new char[lg]).replace("\0", " ");
				} else {
					ret = user;
				}
			} else {
				ret = user;
			}
		}
		return ret;
	}
}
