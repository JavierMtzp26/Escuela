package mx.com.escuela.sistema.dao;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import mx.com.escuela.sistema.logic.model.GenericVO;
import mx.com.escuela.sistema.logic.model.ListBAVO;
import mx.com.escuela.common.dao.OracleConnection;
import mx.com.escuela.common.logic.Constants.CDataSource;
import mx.com.escuela.sistema.logic.model.ACPostVO;
import mx.com.escuela.sistema.logic.model.ActualizarAlumnoVO;
import mx.com.escuela.sistema.logic.model.BorrarCalificacionVO;
import mx.com.escuela.sistema.logic.model.BusquedaAlumnoVO;
import oracle.jdbc.OracleTypes;;

public class OracleProcedures extends OracleConnection {

	private final static Logger LOG = LogManager.getLogger(OracleProcedures.class);
	
	
	public OracleProcedures() {
		super(LOG);
	}
	@SuppressWarnings("unused")
	private void collector(ResultSet rsetOBJ, CallableStatement stmsOBJ, Connection connOBJ) {

		if (rsetOBJ != null) {
			try {
				rsetOBJ.close();
			} catch (SQLException e) {
				// throw new SQLException("Problemas al cerrar los objetos de
				// conexion a base [ResultSet] ", e);
				rsetOBJ = null;
			}
			if (stmsOBJ != null) {
				try {
					stmsOBJ.close();
				} catch (SQLException e) {
					// throw new SQLException("Problemas al cerrar los objetos
					// de Statment de la base", e);
					stmsOBJ = null;
				}
			}
		}
		if (connOBJ != null) {
			try {
				connOBJ.close();
			} catch (SQLException e) {
				// throw new SQLException("Problemas al cerrar los objetos de
				// conexion a base [Connection] ", e);
				connOBJ = null;
			}
		}

	}

	@SuppressWarnings("unused")
	private void collector(CallableStatement stmsOBJ, Connection connOBJ) {

		if (stmsOBJ != null) {
			try {
				stmsOBJ.close();
			} catch (SQLException e) {
				// throw new SQLException("Problemas al cerrar los objetos de
				// Statment de la base", e);
				stmsOBJ = null;
			}
		}
		if (connOBJ != null) {
			try {
				connOBJ.close();
			} catch (SQLException e) {
				// throw new SQLException("Problemas al cerrar los objetos de
				// conexion a base [Connection] ", e);
				connOBJ = null;
			}
		}

	}

	@SuppressWarnings("unused")
	private void collector(PreparedStatement stmsOBJ) {
		if (stmsOBJ != null) {
			try {
				stmsOBJ.close();
			} catch (SQLException e) {
				stmsOBJ = null;
			}
		}
	}

	private void collector(CallableStatement stmsOBJ) {
		if (stmsOBJ != null) {
			try {
				stmsOBJ.close();
			} catch (SQLException e) {
				stmsOBJ = null;
			}
		}
	}

	private void collector(ResultSet rsetOBJ) {

		if (rsetOBJ != null) {
			try {
				rsetOBJ.close();
			} catch (SQLException e) {
				rsetOBJ = null;
			}
		}
	}

	@SuppressWarnings("unused")
	private void collector_escuela(PreparedStatement ps, Connection connOBJ, ResultSet rsetOBJ) throws SQLException {

		if (rsetOBJ != null) {
			try {
				rsetOBJ.close();
				// rsetOBJ=null;
			} catch (SQLException e) {
				// throw new SQLException("Problemas al cerrar los objetos de
				// conexion a base [ResultSet] ", e);
				rsetOBJ = null;
			}
		}

		if (ps != null) {
			try {
				ps.close();
				// ps=null;
			} catch (SQLException e) {
				// throw new SQLException("Problemas al cerrar los objetos de
				// conexion a base [PreparedStatement] ",e);
				ps = null;
			}
		}
		if (connOBJ != null) {
			try {
				connOBJ.close();
				// connOBJ=null;

			} catch (SQLException e) {

				// throw new SQLException("Problemas al cerrar los objetos de
				// conexion a base [Connection] ", e);
				connOBJ = null;
			}
		}

	}

	
	
	public GenericVO agregarCalificacion(ACPostVO aCalif) throws Exception {
		info("Inicia :: agregarCalificacion ::  OracleProcedures");
		GenericVO response = new GenericVO();
		
		
		CallableStatement stmsOBJ = null;
		ResultSet rsetOBJ = null;
		
		try (Connection connOBJ = OracleConnection.getConnection(CDataSource.CORE_ESCUELA_SERVICE_ORACLE)) {

			String query = "{call NESCO.ESCUELA.INS_CALIFICACIONES_SP(?,?,?,?,?,?)} ";
			info("NESCO.ESCUELA.INS_CALIFICACIONES_SP("+ aCalif.getIdMateria() +", "+ aCalif.getIdUsuario() +", "+ aCalif.getCalificacion() +", "+ aCalif.getFechaRegistro() +")");
			stmsOBJ = connOBJ.prepareCall(query);

			stmsOBJ.setInt(1, aCalif.getIdMateria());
			stmsOBJ.setInt(2, aCalif.getIdUsuario());
			stmsOBJ.setDouble(3, aCalif.getCalificacion());
			stmsOBJ.setString(4, aCalif.getFechaRegistro());
			stmsOBJ.registerOutParameter(5, OracleTypes.VARCHAR);
			stmsOBJ.registerOutParameter(6, OracleTypes.VARCHAR);

			stmsOBJ.execute();
			response.setMsg(stmsOBJ.getString(6));
			info("	:: response  ::  msg  ::    "+stmsOBJ.getString(6));
			response.setSucces(stmsOBJ.getString(7));
			info("	:: response ::  succes  ::   "+stmsOBJ.getString(7));
			
		} catch (Exception e) {
			response.setMsg("Ocurrio un problema durante la insercion");
			response.setSucces("ERR");
		} finally {
			if (rsetOBJ != null) {
				collector(rsetOBJ);
			}
			if (stmsOBJ != null) {
				collector(stmsOBJ);
			}

		}
		
		// +++++++++++C O D I G O  P R U E B A S
//				try {
//					
//					response.setMsg("calificacion registrada");
//					response.setSucces("ok");
//								
//				}catch (Exception e) {
//					// TODO: handle exception
//				}
		// +++++++++++F I N  C O D I G O  P R U E B A S
				
				
		info("Fin :: agregarCalificacion :: OracleProcedures");
		return response;
	}
	
	public GenericVO actualizarAlumno(ActualizarAlumnoVO actAlum) throws Exception {
		info("Inicia :: actualizarAlumno ::  OracleProcedures");
		GenericVO response = new GenericVO();
		
		
		CallableStatement stmsOBJ = null;
		ResultSet rsetOBJ = null;
		
		try (Connection connOBJ = OracleConnection.getConnection(CDataSource.CORE_ESCUELA_SERVICE_ORACLE)) {

			String query = "{call NESCO.ESCUELA.UPD_CALIFICACIONES_SP(?,?,?,?,?)} ";
			info("NESCO.ESCUELA.UPD_CALIFICACIONES_SP("+ actAlum.getIdUsuario() +", "+ actAlum.getIdMateria() +", "+ actAlum.getCalificacion() +")");
			stmsOBJ = connOBJ.prepareCall(query);

			stmsOBJ.setInt(1, actAlum.getIdUsuario());
			stmsOBJ.setDouble(2, actAlum.getIdMateria());
			stmsOBJ.setDouble(3, actAlum.getCalificacion());
			stmsOBJ.registerOutParameter(4, OracleTypes.VARCHAR);
			stmsOBJ.registerOutParameter(5, OracleTypes.VARCHAR);

			stmsOBJ.execute();
			response.setMsg(stmsOBJ.getString(4));
			info("	:: response  ::  msg  ::    "+stmsOBJ.getString(4));
			response.setSucces(stmsOBJ.getString(5));
			info("	:: response ::  succes  ::   "+stmsOBJ.getString(5));
			
		} catch (Exception e) {
			response.setMsg("Ocurrio un problema durante la actualizacion");
			response.setSucces("ERR");
		} finally {
			if (rsetOBJ != null) {
				collector(rsetOBJ);
			}
			if (stmsOBJ != null) {
				collector(stmsOBJ);
			}

		}
		
		
		// +++++++++++C O D I G O  P R U E B A S
//		try {
//			
//			response.setMsg("calificacion actualizada");
//			response.setSucces("ok");
//						
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
		// +++++++++++F I N  C O D I G O  P R U E B A S
		
		
		info("Fin :: actualizarAlumno :: OracleProcedures");
		return response;
	}
	
	public GenericVO borrarCalificacion(BorrarCalificacionVO borrarCali) throws Exception {
		info("Inicia :: borrarCalificacion ::  OracleProcedures");
		GenericVO response = new GenericVO();
		
		
		CallableStatement stmsOBJ = null;
		ResultSet rsetOBJ = null;
		
		try (Connection connOBJ = OracleConnection.getConnection(CDataSource.CORE_ESCUELA_SERVICE_ORACLE)) {

			String query = "{call NESCO.ESCUELA.DEL_CALIFICACIONES_SP(?,?,?,?)} ";
			info("NESCO.ESCUELA.DEL_CALIFICACIONES_SP("+ borrarCali.getIdUsuario() +", "+ borrarCali.getIdMateria() +")");
			stmsOBJ = connOBJ.prepareCall(query);

			stmsOBJ.setInt(1, borrarCali.getIdUsuario());
			stmsOBJ.setDouble(2, borrarCali.getIdMateria());
			stmsOBJ.registerOutParameter(3, OracleTypes.VARCHAR);
			stmsOBJ.registerOutParameter(4, OracleTypes.VARCHAR);

			stmsOBJ.execute();
			response.setMsg(stmsOBJ.getString(3));
			info("	:: response  ::  msg  ::    "+stmsOBJ.getString(3));
			response.setSucces(stmsOBJ.getString(4));
			info("	:: response ::  succes  ::   "+stmsOBJ.getString(4));
			
		} catch (Exception e) {
			response.setMsg("Ocurrio un problema durante la eliminacion");
			response.setSucces("ERR");
		} finally {
			if (rsetOBJ != null) {
				collector(rsetOBJ);
			}
			if (stmsOBJ != null) {
				collector(stmsOBJ);
			}

		}
		
		// +++++++++++C O D I G O  P R U E B A S
//				try {
//					
//					response.setMsg("calificacion eliminada");
//					response.setSucces("ok");
//								
//				}catch (Exception e) {
//					// TODO: handle exception
//				}
		// +++++++++++F I N  C O D I G O  P R U E B A S
		
		
		
		info("Fin :: borrarCalificacion :: OracleProcedures");
		return response;
	}
	
	
	public ListBAVO busquedaAlumno(int idUsuario) throws Exception {
		info("Inicia :: busquedaAlumno ::  OracleProcedures");
		BusquedaAlumnoVO busquedaAlum = new BusquedaAlumnoVO();
		List<BusquedaAlumnoVO> listaAlumno = new ArrayList<BusquedaAlumnoVO>();

		ListBAVO listaFinal = new ListBAVO();
		
		CallableStatement stmsOBJ = null;
		ResultSet rsetOBJ = null;
		double promedio = 0.0;
		double sumaCalif = 0.0;
		double calif = 0.0;
		try (Connection connOBJ = OracleConnection.getConnection(CDataSource.CORE_ESCUELA_SERVICE_ORACLE)) {

			String query = "{ ? =  call NESCO.ESCUELA..SEL_BUSQUEDA_ALUMNO_FN(?)} ";
			info("NESCO.ESCUELA..SEL_BUSQUEDA_ALUMNO_FN( " + idUsuario + ")");
			stmsOBJ = connOBJ.prepareCall(query);
			stmsOBJ.registerOutParameter(1, OracleTypes.CURSOR);
			stmsOBJ.setInt(2, idUsuario);
			stmsOBJ.execute();
			rsetOBJ = (ResultSet) stmsOBJ.getObject(1);
			while (rsetOBJ.next()) {
				
				 
				busquedaAlum = new BusquedaAlumnoVO();
				info("BusquedaAlumnoVO() :: ");
				busquedaAlum.setIdUsuario(rsetOBJ.getInt(1));
				info("IdUsuario :: "+(rsetOBJ.getInt(1)));
				busquedaAlum.setNombre(rsetOBJ.getString(2) == null ? "" : rsetOBJ.getString(2));
				info("Nombre :: "+(rsetOBJ.getString(2) == null ? "" : rsetOBJ.getString(2)));
				
				busquedaAlum.setApellido(rsetOBJ.getString(3) == null ? "" : rsetOBJ.getString(3));
				info("Apellido :: "+(rsetOBJ.getString(3) == null ? "" : rsetOBJ.getString(3)));
				busquedaAlum.setMateria(rsetOBJ.getString(4) == null ? "" : rsetOBJ.getString(4));
				info("Materia :: "+(rsetOBJ.getString(4) == null ? "" : rsetOBJ.getString(4)));
				busquedaAlum.setCalificacion(rsetOBJ.getDouble(5));
				info("Calificacion :: "+(rsetOBJ.getDouble(5)));
				calif = rsetOBJ.getDouble(5);
				sumaCalif = sumaCalif + calif;
				busquedaAlum.setFechaRegistro(rsetOBJ.getString(6) == null ? "" : rsetOBJ.getString(6));
				info("FechaRegistro :: "+(rsetOBJ.getString(6) == null ? "" : rsetOBJ.getString(6)));
				
				
				
				
				
				
				
				listaAlumno.add(busquedaAlum);
				
			}
			
//			//Promedio
			promedio = sumaCalif / listaAlumno.size();
			
			
			DecimalFormat df = new DecimalFormat("#.00");
		
			listaFinal.setListaBAVO(listaAlumno);
			listaFinal.setPromedio(Double.parseDouble(df.format(promedio)));
			
			info("Fin :: listaAlumno ::  Total  ::  "+listaAlumno.size());
		} catch (Exception e) {
			throw new Exception("Problemas al obtener busquedaAlumno  " , e);
		} finally {
			if (rsetOBJ != null) {
				collector(rsetOBJ);
			}
			if (stmsOBJ != null) {
				collector(stmsOBJ);
			}
	
		}
		
		
		// +++++++++++C O D I G O  P R U E B A S
//		try {
//			
//						
//							busquedaAlum = new BusquedaAlumnoVO();
//							info("BusquedaAlumnoVO() :: ");
//							busquedaAlum.setIdUsuario(1);
//							busquedaAlum.setNombre("Javier");
//							busquedaAlum.setApellido("Martinez");
//							busquedaAlum.setMateria("Programacion");
//							busquedaAlum.setCalificacion(10.0);
//							calif = 10.0;
//							sumaCalif = sumaCalif + calif;
//							busquedaAlum.setFechaRegistro("04/09/2022");
//							listaAlumno.add(busquedaAlum);
//						
//							busquedaAlum = new BusquedaAlumnoVO();
//							info("BusquedaAlumnoVO() :: ");
//							busquedaAlum.setIdUsuario(1);
//							busquedaAlum.setNombre("Javier");
//							busquedaAlum.setApellido("Martinez");
//							busquedaAlum.setMateria("Matematicas");
//							busquedaAlum.setCalificacion(9.5);
//							calif = 9.5;
//							sumaCalif = sumaCalif + calif;
//							busquedaAlum.setFechaRegistro("05/09/2022");
//							listaAlumno.add(busquedaAlum);
//							
//							busquedaAlum = new BusquedaAlumnoVO();
//							info("BusquedaAlumnoVO() :: ");
//							busquedaAlum.setIdUsuario(1);
//							busquedaAlum.setNombre("Javier");
//							busquedaAlum.setApellido("Martinez");
//							busquedaAlum.setMateria("Ingles");
//							busquedaAlum.setCalificacion(8.3);
//							calif = 8.3;
//							sumaCalif = sumaCalif + calif;
//							busquedaAlum.setFechaRegistro("10/07/2022");
//							listaAlumno.add(busquedaAlum);
//							
//							busquedaAlum = new BusquedaAlumnoVO();
//							info("BusquedaAlumnoVO() :: ");
//							busquedaAlum.setIdUsuario(1);
//							busquedaAlum.setNombre("Javier");
//							busquedaAlum.setApellido("Martinez");
//							busquedaAlum.setMateria("Espa�ol");
//							busquedaAlum.setCalificacion(7.7);
//							calif = 7.7;
//							sumaCalif = sumaCalif + calif;
//							busquedaAlum.setFechaRegistro("25/04/2022");
//							listaAlumno.add(busquedaAlum);
//						
//						
//						//Promedio
//						promedio = sumaCalif / listaAlumno.size();
//						
//						DecimalFormat df = new DecimalFormat("#.00");
//						
//						listaFinal.setListaBAVO(listaAlumno);
//						listaFinal.setPromedio(Double.parseDouble(df.format(promedio)));
//						
//		}catch (Exception e) {
//			// TODO: handle exception
//		}
		// +++++++++++F I N  C O D I G O  P R U E B A S
		
		
		info("Fin :: busquedaAlumno :: OracleProcedures");
		return listaFinal;
	}

	
}