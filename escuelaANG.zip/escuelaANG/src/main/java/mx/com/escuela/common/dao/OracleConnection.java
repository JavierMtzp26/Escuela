package mx.com.escuela.common.dao;
import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.logging.log4j.Logger;

import mx.com.escuela.common.logic.Constants.CDataSource;
import mx.com.escuela.common.logic.Logic;


@SuppressWarnings("all")
public class OracleConnection extends Logic {
	public OracleConnection(Logger log) {
		// TODO Auto-generated constructor stub
		super(log);
	}

	public static Connection getConnection(int baseID) throws Exception {
		Connection connection = null;
		switch (baseID) {

		case CDataSource.CORE_ESCUELA_SERVICE_ORACLE:
			connection = regresContexto().getConnection();
			break;
		
			
		default:
				break;
		}
		return connection;
	}

	private static DataSource regresContexto() throws Exception {
		Context initContext = new InitialContext();
		DataSource ds = null;
		try {			
			ds = (DataSource) initContext.lookup("JDBC/ESCUELA");
			ds.setLoginTimeout(30);
		} catch (Exception e) {
			throw new Exception(
					"Error al regresar el contexto en ESCUELAANG java:/JDBC/ESCUELA");
		}
		return ds;
	}
	
	
	
	
	
	
	
}