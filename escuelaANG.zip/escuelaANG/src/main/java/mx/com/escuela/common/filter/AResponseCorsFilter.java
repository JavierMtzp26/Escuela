package mx.com.escuela.common.filter;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MultivaluedMap;


/**
 * Filtro abstracto para verificar CORS
 * 
 *	@Provider
 *	@Priority(Priorities.HEADER_DECORATOR)
 *	@RequestScoped
 * 
 * @author Miguel Angel Ortega Avila (mo351v)
 */
public abstract class AResponseCorsFilter implements ContainerResponseFilter {
	
	@Context
	protected HttpServletRequest request;
	
	protected abstract String getCorsOrigin();
	
	protected abstract String getCorsMethod();

	@Override
	public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext) {
		
		MultivaluedMap<String, Object> headers = responseContext.getHeaders();
		String origin = getCorsOrigin();
		if (origin.trim().equals("*")) {
			headers.add("Access-Control-Allow-Origin", request.getHeader("Origin"));
        } else {
        	headers.add("Access-Control-Allow-Origin", origin);
        }
		headers.add("Access-Control-Allow-Headers", "Accept, Origin, Referer, User-Agent, Content-Type, Cookie, attESHr, attESSec");
		headers.add("Access-Control-Allow-Methods", getCorsMethod());
		headers.add("Access-Control-Allow-Credentials", "true");
		String reqHead = requestContext.getHeaderString("Access-Control-Request-Headers");
		
		if (null != reqHead) {
			headers.add("Access-Control-Allow-Headers", reqHead);
		}
		//
	}
}
