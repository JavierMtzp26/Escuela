package mx.com.escuela.sistema.api;



import java.io.IOException;
import java.util.ArrayList;



import javax.enterprise.context.RequestScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


import mx.com.escuela.sistema.logic.AdministracionEscuelaLogic;
import mx.com.escuela.sistema.logic.model.ACPostVO;
import mx.com.escuela.sistema.logic.model.ActualizarAlumnoVO;
import mx.com.escuela.sistema.logic.model.BorrarCalificacionVO;
import mx.com.escuela.sistema.logic.model.GenericVO;
import mx.com.escuela.sistema.logic.model.ListBAVO;


@RequestScoped
@Path("/escuela")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class Escuela {

	@GET
	@Path("/version")
	@Produces(MediaType.APPLICATION_JSON)
	public Response version() throws IOException {
		final String version = "Version = 1.0v   Proyecto";
		final ArrayList<String> datos = new ArrayList<String>();
		datos.add(version);
		return Response.ok(datos).build();

	}



	

	

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/busquedaAlumno/{idUsuario}")
	public Response busquedaAlumno(@PathParam("idUsuario") final int idUsuario){
		
		AdministracionEscuelaLogic call = new AdministracionEscuelaLogic();
		ListBAVO res =  call.busquedaAlumno(idUsuario);
				
		return Response.ok(res).build(); 
	}
	
	@POST
	@Path("/altaCalificacion")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response altaCalificacion (ACPostVO aCalif){
		

		AdministracionEscuelaLogic call = new AdministracionEscuelaLogic();
		GenericVO res =  call.agregarCalificacion(aCalif);

		

		return Response.ok(res).build();
	}
	
	
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/ActualizarAlumno")
	public Response actualizarAlumno(ActualizarAlumnoVO actAlum){
		
		AdministracionEscuelaLogic call = new AdministracionEscuelaLogic();
		
		GenericVO res =  call.actualizarAlumno(actAlum);
		
		return Response.ok(res).build(); 
	}



	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/borrarCalificacion")
	public Response borrarCalificacion(BorrarCalificacionVO borrarCali){
		
		AdministracionEscuelaLogic call = new AdministracionEscuelaLogic();
		GenericVO res =  call.borrarCalificacion(borrarCali);
		
		
		return Response.ok(res).build(); 
	}
	
	



	
	
	

	
}
